#include "StupidBot.h"

StupidBot::StupidBot()
{

}

StupidBot::~StupidBot()
{

}

void StupidBot::Proccess()
{
	thrust = 1.0f;
	sideThrustFront = 1.0f;
	sideThrustBack = 1.0f;
	shoot = true;
}