#include "BotBase.h"

BotBase::BotBase()
{
	gameState = NULL;
	botShip = NULL;
	thrust = 1.0f;
	sideThrustFront = 1.0f;
	sideThrustBack = 1.0f;
	shoot = true;
}

BotBase::~BotBase()
{
	
}
	
void BotBase::Update()
{
	if(gameState != NULL)
	{
		if(botShip != NULL)
		{
			Proccess();
		}
	
		gameState->SetThrust(thrust);
		gameState->SetSideThrustFront(thrust);
		gameState->SetSideThrustBack(thrust);
		gameState->SetShoot(shoot);
	}
}

void BotBase::Proccess()
{
	
}