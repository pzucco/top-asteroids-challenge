#include <string>
#include <iostream>
#include <sstream>
#include <vector>
#include "bot_interface.h"

using namespace std;

GameState::GameState()
{
	thrust = 1.0f;
	sideThrustFront = 1.0f;
	sideThrustBack = 1.0f;
	shoot = true;
	botShip = new Ship(0, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0, 0);
}

GameState::~GameState()
{
	for(map<int, Ship*>::iterator itr = ships.begin(); itr != ships.end(); itr++)
    {
        delete itr->second;
    }
    
    for(map<int, Rock*>::iterator itr = rocks.begin(); itr != rocks.end(); itr++)
    {
        delete itr->second;
    }
    
    for(map<int, Laser*>::iterator itr = lasers.begin(); itr != lasers.end(); itr++)
    {
       delete itr->second;
    }
}

void GameState::Update()
{
	ReadData();
}

void GameState::ReadData()
{ 
	string data;
	std::getline(std::cin, data);
	cerr << data << endl; 

	
	ParseData(data);
}

void GameState::ParseData(string toParse)
{
	vector<int> shipIds;
	vector<int> rockIds;
	vector<int> laserIds;
	
	while(toParse.size() > 0)
	{
		string item;
		size_t delim = toParse.find('|');
		if(delim != std::string::npos)
			item = toParse.substr(0, delim + 1);
		else
			item = toParse;	
			
		toParse.erase(0,item.size());
		
		stringstream ssr(item);
		
		string type;
		ssr >> type;
		
		if(type.compare("uid") == 0)
		{
			int uid;
			ssr >> uid;
			botShip->uid = uid;
			std::pair<int, Ship*> shipPair(botShip->uid, botShip);
			ships.insert(shipPair);			
		}
		else if(type.compare("timestep") == 0)
		{
			ssr >> timeStep;
		}
		else if(type.compare("tick") == 0)
		{
			ssr >> tick;
		}
		else if(type.compare("arena.radius") == 0)
		{
			ssr >> arenaRadius;
		}
		else if(type.compare("ship") == 0)
		{
			int uid;
			float posx;
			float posy;
			float velx;
			float vely;
			float radius;
			float ang;
			float velAng;
			int ammo;
			int score;
			
			ssr >> uid;
			ssr >> posx;
			ssr >> posy;
			ssr >> velx;
			ssr >> vely;
			ssr >> radius;
			ssr >> ang;
			ssr >> velAng;
			ssr >> ammo;
			ssr >> score;
			
			shipIds.push_back(uid);
			
			if(ships[uid] == NULL)
			{
				Ship * newShip = new Ship(uid, posx, posy, velx, vely, radius, ang, velAng, ammo, score);
				std::pair<int, Ship*> shipPair(newShip->uid, newShip);
				ships.insert(shipPair);
			}
			else 
			{
				ships[uid]->uid = uid;       
				ships[uid]->posx = posx;
				ships[uid]->posy = posy;
				ships[uid]->velx = velx;
				ships[uid]->vely = vely;
				ships[uid]->radius = radius;
				ships[uid]->ang = ang;
				ships[uid]->velAng = velAng;
				ships[uid]->ammo = ammo;
				ships[uid]->score = score;
			}
			
			cerr << ships[uid]->uid << " " << ships[uid]->posx << " " << ships[uid]->posy << " " << ships[uid]->velx << " " << ships[uid]->vely << " " << ships[uid]->radius << " " << ships[uid]->ang << " " << ships[uid]->velAng << " " << ships[uid]->ammo << " " << ships[uid]->score << endl;
		}
		else if(type.compare("rock") == 0)
		{
			int uid;
			float posx;
			float posy;
			float velx;
			float vely;
			float radius;
			
			ssr >> uid;
			ssr >> posx;
			ssr >> posy;
			ssr >> velx;
			ssr >> vely;
			ssr >> radius;
			
			rockIds.push_back(uid);
			
			if(rocks[uid] == NULL)
			{
				Rock * newRock = new Rock(uid, posx, posy, velx, vely, radius);
				std::pair<int, Rock*> rockPair(newRock->uid, newRock);
				rocks.insert(rockPair);
			}
			else 
			{
				rocks[uid]->uid = uid;       
				rocks[uid]->posx = posx;
				rocks[uid]->posy = posy;
				rocks[uid]->velx = velx;
				rocks[uid]->vely = vely;
				rocks[uid]->radius = radius;
			}
		}
		else if(type.compare("laser") == 0)
		{
			int uid;
			float posx;
			float posy;
			float velx;
			float vely;
			float radius;
			int owner;
			
			ssr >> uid;
			ssr >> posx;
			ssr >> posy;
			ssr >> velx;
			ssr >> vely;
			ssr >> radius;
			ssr >> owner;
			
			laserIds.push_back(uid);
			
			if(lasers[uid] == NULL)
			{
				cerr << "Oiii" << endl;
				Laser * newLaser = new Laser(uid, posx, posy, velx, vely, radius, owner);
				cerr << "Oiii" << endl;
				//std::pair<int, Laser*> laserPair(newLaser->uid, newLaser);
				cerr << "Oiii" << endl;
				lasers.insert(std::pair<int, Laser*>(newLaser->uid, newLaser));
				cerr << "Oiii " << lasers[uid] << endl;
			}
			else 
			{
				lasers[uid]->uid = uid;       
				lasers[uid]->posx = posx;
				lasers[uid]->posy = posy;
				lasers[uid]->velx = velx;
				lasers[uid]->vely = vely;
				lasers[uid]->radius = radius;
				lasers[uid]->owner = owner;
			}
			cerr << "foi" << endl;

			if(lasers[uid] == NULL)
			 	cerr << "NULL" << endl;
			cerr << lasers[uid]->uid << " " << lasers[uid]->posx << " " << lasers[uid]->posy << " " << lasers[uid]->velx << " " << lasers[uid]->vely << " " << lasers[uid]->radius << " " << lasers[uid]->owner << endl;
			cerr << "fudeu" << endl;
		}
	}
	
	for(map<int, Ship*>::iterator itr = ships.begin(); itr != ships.end();)
    {
    	bool found = false;
    	
        for(int i = 0; i < shipIds.size(); ++i)
        {
        	if(itr->first == shipIds[i])
        	{
        		found = true;
        	}
        }
        
        if(!found)
        {
        	delete itr->second;
        	ships.erase(itr++);
        }
        else
        {
        	itr++;
        }
    }

    for(map<int, Rock*>::iterator itr = rocks.begin(); itr != rocks.end(); itr++)
    {
       bool found = false;
    	
        for(int i = 0; i < rockIds.size(); ++i)
        {
        	if(itr->first == shipIds[i])
        	{
        		found = true;
        	}
        }
        
        if(!found)
        {
        	delete itr->second;
        	rocks.erase(itr++);
        }
        else
        {
        	itr++;
        }
    }
    
    for(map<int, Laser*>::iterator itr = lasers.begin(); itr != lasers.end(); itr++)
    {
       bool found = false;
    	
        for(int i = 0; i < laserIds.size(); ++i)
        {
        	if(itr->first ==laserIds[i])
        	{
        		found = true;
        	}
        }
        
        if(!found)
        {
        	delete itr->second;
        	lasers.erase(itr++);
        }
        else
        {
        	itr++;
        }
    }
}

void GameState::WriteData()
{

	
	std::cout << thrust << " " << sideThrustFront << " " << sideThrustBack << " " << shoot << endl;
	std::cerr << thrust << " " << sideThrustFront << " " << sideThrustBack << " " << shoot << endl;
}
