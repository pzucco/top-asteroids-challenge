#include <iostream>
#include "bot_interface.h"
#include "BotBase.h"

using namespace std;

int main (int argc, char *argv[])
{	
	GameState * gameState = new GameState();
	BotBase * stupidBot = new BotBase();
	stupidBot->gameState = gameState;
	stupidBot->botShip = gameState->botShip;
	
	while(stupidBot->botShip != NULL)
	{
		gameState->Update();
		stupidBot->Update();
		gameState->WriteData();
	}
	
	delete gameState;
	delete stupidBot;
	
	return 0;
}