#ifndef BotBase_H
#define BotBase_H

#include "bot_interface.h"

class BotBase
{
protected:
	float thrust;
	float sideThrustFront;
	float sideThrustBack;
	bool shoot;
	
public:
	GameState * gameState;
	Ship * botShip;
	
	BotBase();
	virtual ~BotBase();
	
	void Update();
	virtual void Proccess();
};

#endif
