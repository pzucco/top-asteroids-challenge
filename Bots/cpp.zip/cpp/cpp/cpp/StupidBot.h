#ifndef StupidBot_H
#define StupidBot_H

#include "BotBase.h"

class StupidBot : public BotBase
{
	
public:

	StupidBot();
	virtual ~StupidBot();
	virtual void Proccess();
};

#endif
